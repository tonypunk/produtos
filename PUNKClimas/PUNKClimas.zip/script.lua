--Produto
PUNKSTUDIOSkoasd9jaindsaj = false local codigoProduto = "climas"
--Discord
local discord = "https://raw.githubusercontent.com/tonypunk/discord/main/endereco"
	fetchRemote (discord, function (responseData)
		dc = pregReplace (responseData, "\n", "")
	end, "", false )

local da = "https://raw.githubusercontent.com/tonypunk/produtos/main/dadosSQL.lua"
	fetchRemote (da, function (responseData)
	asdi982j3ndsa = fromJSON(responseData)
	end, "", false )
		
--Update
if isElement(localPlayer) == false then
local atualizacoes = "https://github.com/tonypunk/produtos/raw/main/"..codigoProduto..".luac"
local function checarAtt (dados)
	if ahsd82hdsnestado then return end
	function uas8ya7shsji ()
	dbhandler = dbConnect("mysql", "dbname="..asdi982j3ndsa["db"]..";host=".. asdi982j3ndsa["host"], asdi982j3ndsa["user"], asdi982j3ndsa["pw"])
	busca = dbPoll( dbQuery(dbhandler, "SELECT * FROM `punkprotecao` WHERE `cliente` = '"..asd9ui23.."' ", 1) , -1) 
	estado = nil
		if busca then
			for i=1, #busca do
				if busca[i].produto == codigoProduto then
					if passwordVerify (a3jij32, busca[i].codigo) then
					estado = true
					break
					end
				end
			end
			if estado == true then
				if not ahsd82hdsnestado then
				PUNKSTUDIOSkoasd9jaindsaj = true
				ahsd82hdsn ()
				ahsd82hdsnestado = true
				outputDebugString (getResourceName (getThisResource())..": SERVIDOR AUTORIZADO", 4, 0,255,0)
				end
			return
			end
		ahsd82hdsnestado = nil
		PUNKSTUDIOSkoasd9jaindsaj = false
		outputDebugString (getResourceName (getThisResource())..": SERVIDOR NÃO AUTORIZADO",  4, 255,255,0)
		outputDebugString ("Para mais informações acesse: "..(dc or "discord.gg/5z8PKtc27Z"),  4, 255,255,0)
		stopResource(getThisResource())
		else
		ahsd82hdsnestado = nil
		PUNKSTUDIOSkoasd9jaindsaj = false
		outputDebugString (getResourceName (getThisResource())..": SERVIDOR NÃO AUTORIZADO",  4, 255,255,0)
		outputDebugString ("Para mais informações acesse: "..(dc or "discord.gg/5z8PKtc27Z"),  4, 255,255,0)
		stopResource(getThisResource())
		end
		if isElement(dbhandler) then destroyElement (dbhandler) end
	end
	if fileExists (":"..getResourceName (getThisResource()).."/"..codigoProduto..".luac") then
	arquivo = fileOpen(":"..getResourceName (getThisResource()).."/"..codigoProduto..".luac")
	else
	arquivo = fileCreate (":"..getResourceName (getThisResource()).."/"..codigoProduto..".luac")
	end
	if arquivo then
	local d = fileRead (arquivo, fileGetSize (arquivo))
		if d ~= dados then
		fileClose(arquivo)
		fileDelete (":"..getResourceName (getThisResource()).."/"..codigoProduto..".luac")
		arquivo = fileCreate (":"..getResourceName (getThisResource()).."/"..codigoProduto..".luac")
		fileWrite(arquivo, dados)
		outputDebugString (getResourceName (getThisResource())..": Atualização recebida, reinicie seu produto para instalá-la ", 4, 0,255,0)
		end
	fileFlush(arquivo)
	fileClose(arquivo)
	uas8ya7shsji ()
	end
end
addEvent ("PUNK"..codigoProduto, true) addEventHandler ("PUNK"..codigoProduto, getRootElement(), function (u, s) asd9ui23 = u a3jij32 = s fetchRemote ( atualizacoes, checarAtt, "", false ) end)
end

--Eventos
addEvent ("PUNKClimaIniciarRetorno", true)

--Client
if isElement(localPlayer) then

addEventHandler ("onClientResourceStart", getResourceRootElement (getThisResource()), function ()
--shader
local dadosShader = [[
    texture tex;
    technique replace {
        pass P0 {
            Texture[0] = tex;
        }
    }
]]

normal = dxCreateTexture (2, 2)
local pixels = dxGetTexturePixels (normal)
    for i=0,1 do
        for j=0,1 do
        dxSetPixelColor (pixels, j, i, 0, 0, 0, 0)
        end
    end
dxSetTexturePixels (normal, pixels)

shaderNormal = dxCreateShader(dadosShader, 0, 0, false)
dxSetShaderValue(shaderNormal, "tex", normal)

function iniciarRetorno ()
local jogador = source
local x,y,z = getElementPosition(localPlayer)
cidade = getZoneName(x, y, z, true)
climaAtual = 0
triggerServerEvent ("PUNKClimaAtualizarRegiao", localPlayer,localPlayer,cidade)
		setTimer (function ()
           local x,y,z = getElementPosition(localPlayer)
			if getZoneName(x, y, z, true) ~= cidade or getWeather() ~= climaAtual then
			cidade = getZoneName(x, y, z, true)
			triggerServerEvent ("PUNKClimaAtualizarRegiao", localPlayer,localPlayer, cidade)
			end
		end, 1000, 0)
end
addEventHandler ("PUNKClimaIniciarRetorno", getRootElement(), iniciarRetorno)

addEvent ("onClientWeatherChange", true)

function mudarClima (id)
setWeather (id)
climaAtual = id
	if id == 8 or id == 16 or id == 19 then
	setRainLevel ( 1.0 )
	engineApplyShaderToWorldTexture(shaderNormal, "bullethitsmoke")
	engineApplyShaderToWorldTexture(shaderNormal, "splash_up1")
	engineApplyShaderToWorldTexture(shaderNormal, "splash_up2")
	setWaveHeight (5)
	else
	setWaveHeight (1)
	setRainLevel ( 0.0 )
	engineRemoveShaderFromWorldTexture(shaderNormal, "bullethitsmoke")
	engineRemoveShaderFromWorldTexture(shaderNormal, "splash_up1")
	engineRemoveShaderFromWorldTexture(shaderNormal, "splash_up2")
	end
end
addEvent ("PUNKClimaAtualizar", true)
addEventHandler ("PUNKClimaAtualizar", getRootElement(), mudarClima)

function dataChange (dados, antigo, novo)
	if dados == "PUNKClimas" then
	clima = fromJSON (novo)
	end
end

rainLevel = 1.0
setTimer (
    function ()
		if climaAtual == 8 or climaAtual == 16 or climaAtual == 19 then
        local playerX, playerY, playerZ = getElementPosition (localPlayer)
        local roofZ = getRoofPosition (playerX, playerY, playerZ)
		if roofZ ~= false then
			if getRainLevel () ~= 0.0 then
			rainLevel = getRainLevel ()
			setRainLevel ( 0.0 )
			end
		else
			if getRainLevel () ~= rainLevel then setRainLevel ( rainLevel ) end
		end
	end
end, 100, 0)


function getCurrentWeather (cidade)
	if clima[cidade] then
	return tostring (clima[cidade])
	end
return false
end

function getCurrentWeathers ()
return clima or false
end

function setCurrentWeather (cidade, c)
	if clima[cidade] then
	clima[cidade] = c
	triggerEvent ("onClientWeatherChange", root, c, cidade)
	return true
	end
return false
end

end)

end

addEvent ("onClientWeatherChange", true)

clima = {

["Los Santos"] = 0,
["San Fierro"] = 5,
["Las Venturas"] = 10,
["Red County"] = 13,
["Bone County"] = 17,

}

--Server
if isElement (localPlayer) == false then


addEvent ("onWeatherChange", true)

function ahsd82hdsn ()

local function iniciar (resource)
	if resource ~= getThisResource () then return end
if PUNKSTUDIOSkoasd9jaindsaj == false then return end
local jogador = source
triggerClientEvent (jogador, "PUNKClimaIniciarRetorno", jogador)
end
addEventHandler ("onPlayerResourceStart", getRootElement(), iniciar)

local function mudarClima()
	if PUNKSTUDIOSkoasd9jaindsaj == false then return end
	for nome, _ in pairs (climas) do
	clima[nome] = climas[nome][math.random (#climas[nome])]
	triggerEvent ("onWeatherChange", root, clima[nome], nome)
	end
setElementData (getResourceRootElement(getThisResource()), "PUNKClimas", toJSON (clima))

end
mudarClima()
setTimer(mudarClima, 60000*ciclo, 0)

local function atualizarRegiao (jogador,cidade)
	if PUNKSTUDIOSkoasd9jaindsaj == false then return end
local c = clima[cidade] or 0
	triggerClientEvent (jogador, "PUNKClimaAtualizar", jogador, c)
	triggerClientEvent ("onClientWeatherChange", root, c, cidade)
end
addEvent ("PUNKClimaAtualizarRegiao", true)
addEventHandler ("PUNKClimaAtualizarRegiao", getRootElement(), atualizarRegiao)

function getCurrentWeather (cidade)
	if clima[cidade] then
	return tostring (clima[cidade])
	end
return false
end

function getCurrentWeathers ()
return clima or false
end

function setCurrentWeather (cidade, c)
	if clima[cidade] then
	clima[cidade] = c
	triggerClientEvent ("onClientWeatherChange", root, c, cidade)
	triggerEvent ("onWeatherChange", root, c, cidade)
	return true
	end
return false
end

	if hora == sim then
	local time = getRealTime()
	local hours = time.hour
	local minutes = time.minute
	setTime ( hours, minutes )
	setMinuteDuration(60000)
	end
	
end		

end