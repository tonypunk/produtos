--Clima dinâmico PUNK MTA STUDIO--
---------------INICIALIZAÇÃO (NÃO MODIFICAR)---------
sim = true
nao = false
-------------------------CONFIGURAÇÕES --------------
--Descrição: Configurações gerais do mod, modifique a vontade
hora = sim --ativar/desativar hora real
ciclo = 3 -- tempo de duração dos climas em minutos

climas = {			--tabela de climas modificável, já vem configurado nos climas padrões do GTA, para mais informações: https://wiki.multitheftauto.com/wiki/Weather
	["Los Santos"] = {0}, -- Climas de Los Santos
	["San Fierro"] = {8}, -- Climas de San Fierro
	["Las Venturas"] = {0}, -- Climas de Las Venturas
	["Red County"] = {0}, -- Climas de Red County
	["Bone County"] = {0}, -- Climas de Bone County
}
--------------------------------------------------------
