------------------INICIALIZAÇÃO------------------
--Não modificar estes valores
sim = true
nao = false
Licensa = "" --Insira sua licensa
-----------------CONFIGURAÇÕES-----------------

configuracoes = { --Configurações gerais
tecla = "e", --tecla de ação
hud = sim, -- ativar/desativar hud original (vida, colete, dinheiro, armas etc)
nome = nao, -- exibir nomes e barra de vida de outros jogadores
limite = 200, --limite de contas por máquina, 0 = sem limite
}

texto = { --Configurações de texto
inicial = "Bem vindo", -- texto tópico do painel
entrar = "Entrar", -- texto corpo do painel
login = "Insira seu nome", --texto para inserir nome/usuario
senha = "Insira sua senha", --texto para inserior senha
spawn = "Seja bem vindo a San Andreas Stories", --frase de boas vindas aos jogadores
registrar = "Conta criada com sucesso!", --frase ao criar conta
limite = "Limite de contas atingido nesta máquina", -- mensagem ao atingir o limite de contas,
}

spawn = { --Configurações do spawn (nascer) se quiser desativar apague ou anule esta seção
	dinheiro = 300, -- dinheiro que o jogador irá iniciar
	camera = sim, -- camera de inicialização
	localizacao = sim, -- mostrar localização
	personagem = sim, --ativar/desativar selecionar personagem
	-- skins para o jogador escolher quando iniciar no jogo (se selecionarPersonagem estiver desativado uma skin aleatoria sera definida)
	masculinas = {0, 1, 2, 7, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 32, 33, 34, 35, 36, 37, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 57, 58,
	59, 60, 61, 62, 66, 67, 68, 70, 71, 72, 73, 78, 79, 80, 81, 82, 83, 84, 94, 95, 96, 97, 98, 99, 101, 128, 132, 133, 134, 135, 136, 137, 142, 143, 144, 146, 147, 153,
	154, 155, 156, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 170, 171, 173, 174, 175, 176, 177, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 200, 202,
	203, 204, 206, 209, 210, 212, 213, 217, 220, 221, 222, 223, 227, 228, 229, 230, 234, 235, 236, 239, 240, 241, 242, 249, 250, 252, 253, 255, 258, 259, 260, 261, 262, 264,
	268, 290, 291, 292, 293, 294, 295, 296, 297, 299, 302, 303, 305, 306, 308, 309, 310, 312},
	--
	femininas = {9, 10, 11, 12, 31, 38, 39, 40, 41, 53, 54, 55, 56, 63, 64, 69, 75, 76, 77, 85, 87, 88, 89, 90, 91, 92, 93, 129, 130, 131, 138, 139, 140, 141, 145, 148, 150,
	151, 152, 157, 169, 172, 178, 190, 191, 192, 193, 194, 195, 196, 197, 198, 199, 201, 205, 211, 214, 215, 216, 218, 219, 224, 225, 226, 231, 232, 233, 237, 238, 243, 244,
	245, 251, 256, 257, 263, 298, 304},
	--
	posicoes = { --posições iniciais dos jogadores
		--
		{ 
		posicao = {807.9763, -1337.93, 14.54},
		rotacao = 55,
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = {1742.7497, -1860.43, 14.57},
		rotacao = 0,
		interior = 0,
		dimensao = 0,
		},
		--
	},	
}

respawn = { --Configurações do respawn (renascer) se quiser desativar apague ou anule esta seção
	--
	armas = sim, --ativar/desativar perder armas ao morrer
	grana = 10, --quanto dinheiro o jogador perde ao morrer (porcentagem)
	devedor = nao, --ativar/desativar saldo negativo ao morrer (caso o jogador nao possua dinheiro ao morrer)
	tempo = 5, --tempo até o jogador renascer (segundos)
	--
	posicoes = { --posição e cameras de cada respawn
		--
		{
		posicao = {1177, -1320, 14.137756347656, 270},
		camera = {1200.6923828125, -1324.9873046875, 20.398437},
		interior = 0,
		dimensao = 0,
		},
		--
		{
		posicao = { -2666, 630, 13.567041397095, 180},
		camera = {-2664.4501953125, 611.0771484375, 20.454549789429},
		interior = 0,
		dimensao = 0,
		},
		--
		{
		posicao = { 1607,	1818, 10.8203125, 0}, 
		camera = {1607.3310546875, 1839.7470703125, 16.8203125},
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = { 2040, -1420, 16.9921875, 90}, 
		camera =	{	2031.8486328125, -1419.5927734375, 22.9921875},
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = {-2200, -2308, 30.625, -45},
		camera =	{	-2193.5888671875, -2301.6630859375, 36.625 },
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = {208, -65.3, 1.4357746839523, 180},
		camera =	{	208.310546875, -75.525390625, 7.4357746839523 },
		interior = 0,
		dimensao = 0,
		},
		--
		{
		posicao = {1245.8, 336.9, 19.40625, -20}, 
		camera =	{	1250.3759765625, 346.681640625, 25.40625 },
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = {-317.4, 1056.4, 19.59375, 0}, 
		camera =	{	-316.8125, 1066.306640625, 25.59375 },
		interior = 0,
		dimensao = 0,
		},
		--
		{ 
		posicao = {-1514.8, 2527.9, 55.6875, 1.790, 0}, 
		camera =	{ -1514.283203125, 2536.412109375, 61.6875 },
		interior = 0,
		dimensao = 0,
		},
		--
	}
	--
}

dados = { --Configurações dos dados (salvar/carregar) se quiser desativar apague ou anule esta seção
	--
	skin = sim, --salvar skin
	posicao = sim, --salvar posicao
	vida = sim, --salvar vida
	colete = sim, --salvar colete
	armas = sim, --salvar armas
	dinheiro = sim,
	stats = sim, --salvar stats
	roupas = sim, --ativar/desativar salvar roupas do CJ
	--
}

imagem = { --Configurações de imagem se quiser desativar apague ou anule esta seção
personalizada = sim, --ativar/desativar imagem de fundo
}

musica = {  --Configurações da musica se quiser desativar apague ou anule esta seção
personalizada = nao, --ativar/desativar para usar a musica presente na pasta ou a musica do proprio jogo
repetir = sim, --ativar/desativar repetição da musica de entrada
volume = 5, --volume da musica
}

--[[
video = {  --Configurações da video se quiser desativar apague ou anule esta seção
url = "nyk1xKCVFZo", --URL do video no youtube, por exemplo youtu.be/HT_bjzWSomI só use o que vier depois da barra
duracao = 75, --tamanho do video (segundos)
inicio = 1, --trecho do video que a animação irá iniciar
fim = -1, --trecho do video que a animação irá encerrar, -1 para o video ir ate o fim
}
]]

paisagens = { --Configurações de paisagens, se quiser desativar apague ou anule esta seção
	--
	{
	posicao = {2437.0556640625, -1638.505859375, 45.291584014893},
	camera = {2461.3583984375, -1653.2265625, 30.359422683716},
	},
	--
	{
	posicao = {2099, -1120.6904296875, 55.355281829834},
	camera = {2069.6689453125, -1135.8212890625, 56.595420837402},
	},
	--
	{
	posicao = {1288.404296875, -719.2314453125, 112.42658996582},
	camera = {1305.0966796875, -695.025390625, 112.46134185791},
	},
	--
	{
	posicao = {1036.9423828125, -870.8505859375, 102.67305755615},
	camera = { 1097.87109375, -844.4287109375, 113.99040222168},
	},
	--
	{
	posicao = {595.470703125, -480.974609375, 43.642356872559},
	camera = { 639.0654296875, -533.4814453125, 26.665838241577},
	},
	--
	{
	posicao = { 25.9892578125, -146.3505859375, 0.609375},
	camera = {-37.4482421875, -9.986328125, 5.0197405815125},
	},
	--
	{
	posicao = { 2082.736328125, 1326.6630859375, 42.265964508057},
	camera = {2251.0234375, 1294.9208984375, 59.006252288818},
	},
	--
	{
	posicao = { 2440.064453125, 2014.5751953125, 60.817951202393},
	camera = {2372.9267578125, 1979.7666015625, 56.508697509766},
	},
	--
	{
	posicao = {  245.7646484375, 2489.8818359375, 57.371559143066},
	camera = {326.5625, 2505.9404296875, 38.442836761475},
	},
	{
	posicao = {-1414.9267578125, 2639.2783203125, 69.008010864258},
	camera = {-1595.765625, 2558.8916015625, 93.896110534668},
	},
	--
	{
	posicao = {-2392.90234375, 2264.0107421875, 40.823902130127},
	camera = { -2547.34765625, 2328.13671875, 14.969746589661},
	},
	--
	{
	posicao = {-2194.390625, 1151.2197265625, 127.2670211792},
	camera = {-1834.1728515625, 870.9072265625, 127.79608917236},
	},
	--
	{
	posicao = {-1940.736328125, -56.3583984375, 25.638683319092},
	camera = {-1944.525390625, 8.3642578125, 25.7109375},
	},
	--
}

janela = { --Configurações da janela, se quiser desativar apague ou anule esta seção
horizontal = "direita",
vertical = "centro",
cor = {0,0,0},
}