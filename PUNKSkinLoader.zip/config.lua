--PRÉ-CONFIGURAÇÕES, NÃO MODIFICAR --
sim = true
nao = false
--------------------------------------------------
-------------------------CONFIGURAÇÕES --------------

--elementData
elementData = { --tabela de dados para serem salvos através de elementData, gerando compatibilidade com outros mods (exclua se não quiser usar)
nome = "Nome", --elementData do nome do elemento
}
modloader = true
--Configuracoes
configuracoes = {
	------------------------------------
	--Exemplos de bonecos
	------------------------------------
	--
	["Ped 1"] = { --Exemplo de boneco novo
		--
		arquivo = "ped1", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 2"] = { --Exemplo de boneco novo
		--
		arquivo = "ped2", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	["Ped 3"] = { --Exemplo de boneco novo
		--
		arquivo = "ped3", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 4"] = { --Exemplo de boneco novo
		--
		arquivo = "ped4", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 5"] = { --Exemplo de boneco novo
		--
		arquivo = "ped5", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	["Ped 6"] = { --Exemplo de boneco novo
		--
		arquivo = "ped6", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	["Ped 7"] = { --Exemplo de boneco novo
		--
		arquivo = "ped7", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 8"] = { --Exemplo de boneco novo
		--
		arquivo = "ped8", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 9"] = { --Exemplo de boneco novo
		--
		arquivo = "ped9", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 10"] = { --Exemplo de boneco novo
		--
		arquivo = "ped10", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 11"] = { --Exemplo de boneco novo
		--
		arquivo = "ped11", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 12"] = { --Exemplo de boneco novo
		--
		arquivo = "ped12", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 13"] = { --Exemplo de boneco novo
		--
		arquivo = "ped13", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	--
	["Ped 14"] = { --Exemplo de boneco novo
		--
		arquivo = "ped14", --nome dos arquivo na pasta  (.dff, .txd, .col)
		voz = 23, -- ID da voz do personagem
		--
	},
	--
	------------------------------------
}
