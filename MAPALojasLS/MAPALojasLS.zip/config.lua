--Mapa de lojas e comercios PUNK STUDIOS
-----------------------Inicialização-------------------------
--Descrição: Variaveis de inicialização, não modifique
sim = true --não tocar
nao = false	--não tocar
-------------------------CONFIGURAÇÕES --------------
--Alterne entre sim ou nao para ativar/desativar cada loja individualmente
configuracoes = {
Loja1 = sim,
Loja2 = sim,
Loja3 = sim,
Loja4 = sim,
}
-------------------------