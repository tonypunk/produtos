-----------Configurações-------------

comandos = {
deitar = "deitar",
}

controles = {
deitar = "x",
}